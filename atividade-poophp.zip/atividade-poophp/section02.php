<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">

<script type="text/javascript">
	$(document).ready(function() {
		$("#Enviar").click(function() {
			var url   = "section03.php";
			var dados = $("#frmLogin").serialize();
			$.post(url, dados, function(responseText) {
				var objResponse = JSON.parse(responseText);
				var outText = "<b>Status da Autenticação:</b> "+objResponse.login+"<br>"+"<b>Dados:</b><br> "+objResponse.message;  
				$("#sct").html(outText);
				console.log(objResponse);
			} );
		});
	});
</script>
</head>
<body>
<form id="frmLogin" action="section03.php" style="width: 350px; margin-left: 120px;">
	<div class="form-group">
	<label for="usr">Usuário:</label> <input type="text" class="form-control" id="usr" name="usuario" >
	</div>
	<div class="form-group">
	<label for="pwd">Senha:</label><input type="password" class="form-control" id="pwd" name="senha">
	</div>
	<input type="button" class="btn" style="background-color: #451a3e; color: white;" id="Enviar" value="Enviar">
	<input type="reset" class="btn" style="background-color: #451a3e; color: white;" id="Apagar" value="Excluir">
</form>
<br><br><br><br>
<div class="container">
<div class="alert alert-warning">
    <strong>Aviso!</strong> Faça o login para acessar o currículo.
  </div>
</div>

</body>
</html>