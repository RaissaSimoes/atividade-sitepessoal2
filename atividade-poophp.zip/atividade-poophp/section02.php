<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">

<script type="text/javascript">
	$(document).ready(function() {
		$("#Enviar").click(function() {
			var url   = "section03.php";
			var dados = $("#frmLogin").serialize();
			$.post(url, dados, function(responseText) {
				var objResponse = JSON.parse(responseText);
				var outText = "Status da Autenticação: "+objResponse.login+"<br>"+"Dados:<br> "+objResponse.message;  
				$("#sct").html(outText);
				console.log(objResponse);
			} );
		});
	});
</script>
</head>
<body>
<form id="frmLogin" action="section03.php">
	<div class="form-group">
	<label for="usr">Usuario:</label> <input type="text" class="form-control" id="usr" name="usuario" >
	</div>
	<div class="form-group">
	<label for="pwd">Senha:</label><input type="password" class="form-control" id="pwd" name="senha">
	</div>
	<input type="button" class="btn btn-primary" id="Enviar" value="Enviar">
	<input type="reset" class="btn btn-primary" id="Apagar" value="Excluir">
</form>
</body>
</html>