<nav class="navbar navbar-expand-sm navbar-dark">

  <a class="navbar-brand" href="#">Raissa</a>
  
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="#">Home</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">Login</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">Currículo</a>
    </li>
  </ul>
</nav>

<style>
a:link, a:visited {
  padding: 10px 22px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}

a:hover, a:active {
  background-color: black;
}
</style>