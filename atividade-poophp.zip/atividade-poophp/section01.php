<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">

<script> 
$("#login").mouseenter(function(){
  $("#animacao").animate({
    height: 'toggle'
  });
});
</script>

<script type="text/javascript">
	$(document).ready(function() {
		$("#login").click(function() {
			$("#sct").load("section02.php");
		});
	});
</script>

</head>
<body>
<div id="animacao" style="background-image: url(img/sect1.png);height:300px;width:300px;position:absolute;
 margin-top: 130px; margin-left: 40px;"></div>
<br>
<div class="container">
  <div class="card" style="width:200px; margin-left: 350px;">
    <img class="card-img-top" src="img/eu.png" alt="Card image" style="width:100%">
    <div class="card-body">
      <h4 class="card-title">Raissa Simões</h4>
      <p class="card-text">Estudante de Informática para Internet do IFSP.</p>
      <a id="login" class="btn" style="background-color: #451a3e; color: white;">Saiba mais</a>
    </div>
  </div>
</body>
</html>