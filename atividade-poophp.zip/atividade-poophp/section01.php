<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">

<script> 
$("#login").mouseenter(function(){
  $("div").animate({
    height: 'toggle'
  });
});
</script>

<script type="text/javascript">
	$(document).ready(function() {
		$("#login").click(function() {
			$("#sct").load("section02.php");
		});
	});
</script>

</head>
<body>

<div style="background-image: url(img/sect1.png);height:300px;width:300px;position:absolute; margin-left: 65px;"></div>

<input type="button" class="btn btn-info" id="login" value="Login">   

</body>
</html>