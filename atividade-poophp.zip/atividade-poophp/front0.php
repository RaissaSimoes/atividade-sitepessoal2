<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Atividade</title>
		<style type="text/css">
			header{
			    background-color: #451a3e;
				width: 600px;
				height: 70px;
				float: left;
				margin-left: 30%;
			}

			#sct{
				width: 600px;
				height: 600px;
				background-color: #77b1a9;
				margin-left: 30%;
				font-family: Garamond;
				font-size: larger;
			}

			footer{
			    background-color: #451a3e;
				width: 600px;
				height: 100px;
				float: left;	
				margin-left: 30%;		
			}
			
		</style>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script type="text/javascript">
				$(document).ready(function() {
					$("#header").load("header.php");
					$("#sct").load("section01.php");
					$("#footer").load("footer.php");
				});
		</script>
	</head>
<body style="background-color: #f1edd0;">
		<header id="header"></header>
		<section class="sct" id="sct"></section>
		<footer id="footer"></footer>
</body>
</html>