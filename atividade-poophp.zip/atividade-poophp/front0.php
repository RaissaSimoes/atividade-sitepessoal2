<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Atividade</title>
		<style type="text/css">
			body{
			    background-image: url("img/yin_yang.jpg");
			    background-size: cover;
			    background-repeat: no-repeat;
			    margin-left: 500px;
			    margin-top: 80px;
			    color: white;
			    text-align: center;	
			    font-family: Arial;
			}
			
			header{
			    background-image: url("img/Raissa.png");
				width: 430px;
				height: 120px;
				float: left;
				background-color: #343434;
				margin-left: 35%;
			}
			
			#sct{
				width: 430px;
				height: 500px;
				background-color: #0a0c0e;
				margin-left: 35%;
				margin-top: 15px;
				color:white;
			}

			footer{
			    background-image: url("img/footer.png");
				width: 430px;
				height: 100px;
				float: left;	
				background-color: #343434;
				margin-left: 35%;		
			}
			
			#login{
			    margin-top: 320px;
			    margin-left: 180px;
			}
			
		</style>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script type="text/javascript">
				$(document).ready(function() {
					$("#header").load("header.php");
					$("#sct").load("section01.php");
					$("#footer").load("footer.php");
				});
		</script>
	</head>
<body>
		<header id="header"></header>
		<section class="sct" id="sct"></section>
		<footer id="footer"></footer>
</body>
</html>