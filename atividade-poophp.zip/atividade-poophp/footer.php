<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

<style type='text/css'>
.circle-icons {
  padding: 10px;
  font-size: 20px;
  width: 18px;
  text-align: center;
  text-decoration: none;
  margin: 5px 2px;
  border-radius: 50%;  
  background: black;
  color: #fff;
}

.circle-icons:hover {
    background: #ccc;
    color: #fff;
    opacity: 0.7;
}
</style>

<center style="margin-top: 15px;">
<a href="https://www.facebook.com/raissa.simoes.12" class="circle-icons fa fa-facebook"></a>

<a href="https://mail.google.com/mail/u/0/?tab=rm&ogbl#inbox" class="circle-icons fa fa-google"></a>

<a href="https://www.instagram.com/raissasaimoes/" class="circle-icons fa fa-instagram"></a>

<a href="https://github.com/RaissaSimoes" class="circle-icons fa fa-github"></a>

<a href="tel:11983842094" class="circle-icons fa fa-phone"></a>
</center>

<p style="color: white; text-align: center;">&copy;Todos os direitos reservados</p>
