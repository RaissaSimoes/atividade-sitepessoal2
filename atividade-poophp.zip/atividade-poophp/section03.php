<?php 
$usuario = $_REQUEST['usuario'];
$senha = $_REQUEST['senha'];

$logUsuario = "admin";
$logSenha = "12345";

$outArray = array();
if(isset($_REQUEST['usuario']) && isset($_REQUEST['senha'])){
    if (($usuario==$logUsuario)&&($senha==$logSenha)){
        $outArray = array("login"=> "Online<br>","message"=> "<b>Nome:</b> Raissa Simões dos Santos. <br><b> Idade:</b> 18 anos.<br> 
<b>Escola:</b> Instituto Federal de São Paulo campus Guarulhos - IFSP. <br>
<b>Formação:</b> Atualmente estou no 4º ano do Ensino Médio integrado ao curso de Informática para Internet.<br>
Áreas que tenho mais facilidade do curso de informática: Front-End e Hardware. <br>
<b>Cursos:</b> Espanhol - 3 anos.<br>
<b>Projetos:</b> Durante meu 2º ano e 3º ano do E.M. fiz um projeto chamado Libras Translation, que tratava sobre 
como os sites e páginas web não são acessíveis a deficientes auditivos.<br> 
<b>Áreas de interesse:</b> artística - dança e cinema.");
    }else{
        $outArray = array("login"=>"Off", "message"=> "Usuário não Autenticado");
    }    
} else {
    $outArray = array("login"=>"Off", "message"=> "Informe Usuário e Senha");
}

echo json_encode($outArray, JSON_UNESCAPED_UNICODE);
?>