<?php 

$usuario = $_REQUEST['usuario'];
$senha = $_REQUEST['senha'];

$logUsuario = "admin";
$logSenha = "12345";

$outArray = array();
if(isset($_REQUEST['usuario']) && isset($_REQUEST['senha'])){
    if (($usuario==$logUsuario)&&($senha==$logSenha)){
        $outArray = array( "login"=>"Logado", "message"=> "Oii, me chamo Raissa, tenho 18 anos 
e atualmente estou no 4ºAno do Ensino Médio integrado ao curso de Informática para Internet.<br>
Gosto muito de escutar música, dançar, jogar vídeo-game e de assistir dramas e filmes asiáticos." );
    }else{
        $outArray = array("login"=>"Off", "message"=> "Usuário não Autenticado");
    }    
} else {
    $outArray = array("login"=>"Off", "message"=> "Informe Usuário e Senha");
}

echo json_encode($outArray, JSON_UNESCAPED_UNICODE);
?>